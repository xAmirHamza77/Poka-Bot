from fastapi import APIRouter, HTTPException
from typing import Dict, Any
import httpx
from app.config import settings
from app.schemas.contracts import AppSettingsSchema
from app.services.storage_service import storage_service

router = APIRouter(prefix="/api/v1/settings", tags=["settings"])

@router.get("", response_model=AppSettingsSchema)
async def get_settings():
    data = storage_service.get_public_settings()
    return AppSettingsSchema(**data)

@router.post("", response_model=AppSettingsSchema)
async def save_settings(new_settings: AppSettingsSchema):
    storage_service.save_settings(new_settings.model_dump(exclude_unset=True))
    return AppSettingsSchema(**storage_service.get_public_settings())


@router.post("/test")
async def test_provider():
    """Read the saved provider's model catalog without a billable chat request."""
    config = storage_service.get_settings()
    base_url = (config.get("model_api_base_url") or settings.MODEL_API_BASE_URL).rstrip("/")
    if not base_url:
        raise HTTPException(400, "Save an API base URL first.")
    protocol = config.get("model_api_wire_api", "prediction")
    key = config.get("model_api_key") or settings.MODEL_API_KEY
    headers = {**(config.get("model_api_headers") or {}), "Accept": "application/json"}
    if key:
        headers["x-api-key" if protocol == "prediction" else "Authorization"] = key if protocol == "prediction" else f"Bearer {key}"
    try:
        async with httpx.AsyncClient(timeout=15.0, follow_redirects=False) as client:
            response = await client.get(f"{base_url}/models", headers=headers)
        if not response.is_success:
            raise HTTPException(400, f"Model catalog returned HTTP {response.status_code}. Check the endpoint, key, and whether this provider supports /models.")
        payload = response.json()
        entries = payload.get("data", []) if isinstance(payload, dict) else payload
        ids = [entry.get("id") for entry in entries if isinstance(entry, dict) and isinstance(entry.get("id"), str)] if isinstance(entries, list) else []
        if not ids:
            raise HTTPException(400, "The endpoint responded, but did not return a compatible model catalog. Chat support has not been verified.")
        selected = config.get("default_model") or settings.DEFAULT_MODEL
        return {"ok": True, "models": ids, "default_model_found": selected in ids,
                "message": "Connected. The selected model is listed." if selected in ids else "Connected, but the selected model was not listed. Check its exact ID."}
    except HTTPException:
        raise
    except (httpx.HTTPError, ValueError, TypeError):
        raise HTTPException(400, "Could not read the provider model catalog. Check the URL and connection.")
